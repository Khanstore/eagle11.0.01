# -*- coding: utf-8 -*-
from . import exam_evaluation
from . import exam_academic_transcript
from . import exam_academic_transcript1
from . import exam_academic_transcript_s
from . import merit_list
from . import merit_list_history
from . import exam_gpa

