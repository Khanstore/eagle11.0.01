v1.0.2
======
* Fix Send SMS automated action not appearing in list

v1.0.1
======
* Fix real time sms receive bug

v1.0.0
======
* Port to version 11