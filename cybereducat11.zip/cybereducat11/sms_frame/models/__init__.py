# -*- coding: utf-8 -*-

from . import res_partner
from . import sms_account
from . import res_country
from . import ir_actions_server
from . import sms_number
from . import sms_message
from . import sms_gateway
from . import sms_compose
from . import sms_template
from . import sms_gateway_twilio
from . import sms_gateway_ssl
from . import sms_gateway_me
from . import ir_attachment