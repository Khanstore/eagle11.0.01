v1.0.3
======
* Allow changing of stop message

v1.0.2
======
* Add new mass sms group

v1.0.1
======
* Multi record compute issue

v1.0
====
* Initial Release