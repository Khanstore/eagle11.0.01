# -*- coding: utf-8 -*-

from . import education_admission
from . import education_class_division
from . import education_institute
from . import education_academic
from . import education_subject
from . import education_application
from . import education_application_reject
from . import education_class_wizard
from . import education_student
from . import education_student_class
from . import education_faculty
from . import education_faculty_recruitment
from . import education_documents
from . import education_amenties
from . import importpreviousdata
